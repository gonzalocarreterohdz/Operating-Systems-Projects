// Extracted function used for performing an operation (CREATE, DEPOSIT,
// WITHDRAW, BALANCE, TRANSFER). This function also updates the corresponding
// account balance (or two account balances for TRANSFER) and the global bank
// balance.