// OS-P3 2022-2023

#include "queue.h"
#include <fcntl.h>
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/**
 * Entry point
 * @param argc
 * @param argv
 * @return
 */
// Macro to obtain max(a,b)
#define max(a, b) (((a) > (b)) ? (a) : (b))

// Define global variables.
// Number of operations performed from ATMs, initialized to zero.
int client_numop = 0;
// Number of operations performed from workers, initialized to zero.
int bank_numop = 0;
// Current balance of all accounts, updated with operations. Positive or
// Negative
int global_balance = 0;

// Global variable to store the content of the file
// At most 200 operations
// Assumption: At most 10 operands per line.
// Assumption: each operand is at most 20 bytes.
char list_client_ops[200][10][20];

// Circular queue.
queue *my_queue;

// Declaration of the ATM function (Producer).
void *ATM(void *arg);

// Declaration of the worker function (Consumer).
void *worker(void *arg);

int read_data(int fd, int num_lines);
int perform_operation(struct element *elem);

// Define main function.
int main(int argc, const char *argv[]) {

  // Raise an error if the number of arguments is not 7
  if (argc != 7) {
    perror("Incorrect number of arguments\n");
    exit(1);
  }

  // Open the file.
  int fd = open(argv[1], O_RDONLY);
  // Raise an error if the file could not be opened successfully.
  if (fd < 0) {
    perror("Could not open file\n");
    exit(1);
  }

  // Read the number of lines from the file.
  int num_lines;
  // Raise an error if the file could not be read successfully.
  if (read(fd, &num_lines, sizeof(num_lines)) == -1) {
    perror("read");
    exit(1);
  }

  if(num_lines > 200){
    perror("Number of operations exceeds 200");
    //check mininum?
    exit(1);
  }

  // Read each line and store its contents in the buffer.
  read_data(fd, num_lines);

  // Store the number of producers in the variable 'n_producers'.
  int n_producers = atoi(argv[2]);

  // Store the number of consumers in the variable 'n_consumers'.
  int n_consumers = atoi(argv[3]);

  // Array of integers that contain the balance of each account.
  int account_balance[atoi(argv[4])];

  // Initialize the queue with the maximum number of elems it can have.
  my_queue = queue_init(atoi(argv[5]));

  // Producers threads.
  pthread_t producers[n_producers];

  // Consumers threads.
  pthread_t consumers[n_consumers];

  for (int i; max(n_producers, n_consumers); i++) {
    // Create threads.
    if (i < n_producers)
      pthread_create(&producers[i], NULL, ATM, NULL);
    if (i < n_consumers)
      pthread_create(&consumers[i], NULL, worker, NULL);
  }

  for (int i; i < (n_producers > n_consumers) ? n_producers : n_consumers;
       i++) {
    // Wait thread to exit
    if (i < n_producers)
      pthread_join(producers[i], NULL);
    if (i < n_consumers)
      pthread_join(consumers[i], NULL);
  }

  return 0;
}

// Define ATM function (Producer).
void *ATM() {

  // Read operations from list_client_ops
  while (1) {

    // Lock the mutex to enter the critical section safely.
    pthread_mutex_lock(&my_queue->lock);

    // If the queue is empty.
    if (queue_empty(my_queue)){
      pthread_cond_wait(&my_queue->not_full, &my_queue->lock);
    }
//WOULDNT THIS BE INVERSED FOR PRODUCERS AND CONSUMERS? PRODUCERS DONT NEED TO CHECK IF THE QUEUE IS EMPTY, BUT FULL. WHILE CONSUMERS NEED TO CHECK IF THE QUEUE IS EMPTY, NOT FULL.

    struct element *elem;

    // Exit the loop if there are no more commands.
    if (list_client_ops[client_numop][0][0] == '\0')
      break;

    elem->operation = list_client_ops[client_numop][0];
    int i = 0;

    while (1) {

      // Exit the loop if there are no more operands.
      if (list_client_ops[client_numop][i + 1][0] != '\0')
        break;
      *elem->amounts[i] = atoi(list_client_ops[client_numop][i + 1]);
      i++;
    }
    // Add operations to the circular queue.
    queue_put(my_queue, elem);
    // Increment the number of performed operations.
    client_numop++;

    // Signal that the queue is not empty.
    pthread_cond_signal(&my_queue->not_empty);

    // Release the mutex lock regarding the queue.
    pthread_mutex_unlock(&my_queue->lock);
  }

  // Terminate the calling thread.
  pthread_exit(0);
  return 0;
}

// Define worker function (Consumer).
void *worker() {

  // Read operations from the input file.
  while (1) {

    // Lock the mutex to enter the critical section safely.
    pthread_mutex_lock(&my_queue->lock);

    // If the queue is full, wait for the queue become non-empty.
    if (queue_full(my_queue)){
      pthread_cond_wait(&my_queue->not_empty, &my_queue->lock);
    }

    // Exit the loop if there are no more commands.
    if (list_client_ops[bank_numop][0][0] == '\0')
      break;

    // Extract operation from the circular queue.
    struct element *elem = queue_get(my_queue);

    // Execute operation on the corresponding account.
    perform_operation(elem);

    // Increase the global bank operation counter.
    bank_numop++;

    // Signal that the queue is not full.
    pthread_cond_signal(&my_queue->not_full);

    // Release the mutex lock regarding the queue.
    pthread_mutex_unlock(&my_queue->lock);
  }

  // Terminate the calling thread.
  pthread_exit(0);
  return 0;
}

// Extracted function used for reading the data from a file.
int read_data(int fd, int num_lines) {
  for (int i = 0; i < num_lines; i++) {
    int j = 0;
    while (1) {
      int k = 0;
      while (1) {
        // Raise an error if the file could not be read successfully.
        if (read(fd, &list_client_ops[i][j][k], 1) == -1) {
          perror("Error reading the file");
          exit(1);
        }

        if (list_client_ops[i][j][k] == ' ' ||
            list_client_ops[i][j][k] == '\n' ||
            list_client_ops[i][j][k] == '\0')
          break;
        k++;
      }
      j++;
      if (list_client_ops[i][j][k] == '\n' || list_client_ops[i][j][k] == '\0')
        break;
    }
    if (list_client_ops[i][j][k] == '\0')
      break;
  }
}


// Extracted function used for performing an operation.
int perform_operation(struct element *elem) {
  // Execute operation on corresponding account: CREATE, DEPOSIT, WITHDRAW,
  // BALANCE, TRANSFER Update the corresponding account balance and the global
  // bank balance

  //print on the screen the operations performed
  return 0;
}