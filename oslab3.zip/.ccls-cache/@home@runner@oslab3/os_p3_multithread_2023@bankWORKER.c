// OS-P3 2022-2023

#include "queue.h"
#include <fcntl.h>
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

// Macro to obtain max(a,b).
#define max(a, b) (((a) > (b)) ? (a) : (b))

// Global variable.
// Used as the number of operations / commands.
int *num_lines;

// Global variable.
// Used as the number producers.
int *n_producers;

// Global variable.
// Used as the number consumers.
int *n_consumers;

// Global variable.
// Number of operations performed from ATMs, initialized to zero.
int client_numop = 0;

// Global variable.
// Number of operations performed from workers, initialized to zero.
int bank_numop = 0;

// Global variable.
// Current balance of all accounts, updated with operations.
// It can either be positive or negative.
int global_balance = 0;

// Global variable to store the content of the file.
// At most 200 operations.
// Assumption: At most 10 operands per line.
// Assumption: each operand is at most 20 bytes.
char list_client_ops[200][10][20];

// Circular queue.
queue *my_queue;

// Declaration of the ATM function (Producer).
void *ATM(void *arg);

// Declaration of the worker function (Consumer).
void *worker(void *arg);

// Declaration of the mutex lock and condition variables.
pthread_mutex_t atm_lock;
pthread_cond_t atm_cond;
pthread_mutex_t worker_lock;
pthread_cond_t worker_cond;

// Declaration of the "extracted" read_data function.
int read_data(int fd);

// Declaration of the "extracted" perform_operation function.
int perform_operation(struct element *elem);

// Declaration of the "extracted" handle_operation_error function.
void handle_operation_error(int exists);

// Global pointer used for the listing of account structures.
int *account_balance;

// Global pointer used for indicating the maximum number of accounts.
int *max_accounts;

// Define main function.
int main(int argc, const char *argv[]) {

  // Raise an error if the number of arguments is incorrect.
  if (argc != 6) {
    perror("Incorrect number of arguments. \n");
    exit(1);
  }

  // Open the file.
  int fd = open(argv[1], O_RDONLY);

  // Raise an error if the file could not be opened successfully.
  if (fd < 0) {
    perror("Could not open file. \n");
    exit(1);
  }

  // Maximum number of accounts.
  max_accounts = malloc(sizeof(int));
  *max_accounts = atoi(argv[4]);

  // Read each line and store its contents in list_client_ops.
  read_data(fd);

  // Store the number of ATMs in the variable 'n_producers'.
  n_producers = malloc(sizeof(int));
  *n_producers = atoi(argv[2]);

  // Store the number of Workers in the variable 'n_consumers'.
  n_consumers = malloc(sizeof(int));
  *n_consumers = atoi(argv[3]);

  // Raise an error if the number of producers or consumers is incorrect.
  if (*n_producers < 1 || *n_consumers < 1) {
    perror("Number of producers/consumers must be greater than 0. \n");
    exit(1);
  }

  // Array of integers that contain the balance of each account.
  account_balance = malloc(sizeof(int) * (*max_accounts + 1));

  // Raise an error if the maximum number of bank accounts is incorrect.
  if (*max_accounts <= 0) {
    perror("The number of maximum bank accounts must be greater than 0. \n");
    exit(1);
  }

  // Set every account balance to -1.
  for (int i = 0; i <= *max_accounts; i++) {
    account_balance[i] = -1;
  }

  // Initialize the queue with its maximum number of elements.
  my_queue = queue_init(atoi(argv[5]));

  // Producers threads.
  pthread_t producers[*n_producers];

  // Consumers threads.
  pthread_t consumers[*n_consumers];

  // Initialize the mutex lock and condition variables.
  pthread_mutex_init(&atm_lock, NULL);
  pthread_cond_init(&atm_cond, NULL);
  pthread_mutex_init(&worker_lock, NULL);
  pthread_cond_init(&worker_cond, NULL);

  // Create threads for both producers and consumers.
  for (int i = 0; i < max(*n_producers, *n_consumers); i++) {

    // Create threads for producers.
    if (i < *n_producers) {
      int *thread_id = malloc(sizeof(int)); // Allocate a new integer variable
      *thread_id = i; // Assign the value of i to the new variable

      // Raise an error if the thread could not be created successfully.
      if (pthread_create(&producers[i], NULL, (void *)ATM, thread_id) < 0) {
        perror("Error creating an ATM thread. \n");
        exit(1);
      }
    }

    // Create threads for consumers.
    if (i < *n_consumers) {
      int *thread_id = malloc(sizeof(int)); // Allocate a new integer variable
      *thread_id = i; // Assign the value of i to the new variable

      // Raise an error if the thread could not be created successfully.
      if (pthread_create(&consumers[i], NULL, (void *)worker, thread_id) < 0) {
        perror("Error creating a worker thread. \n");
        exit(1);
      }
    }
  }

  // Wait for the finish of the threads.
  for (int i = 0; i < max(*n_producers, *n_consumers); i++) {

    // Wait for the producers' threads to exit.
    if (i < *n_producers) {

      // Raise an error if the thread could not be joined successfully.
      if (pthread_join(producers[i], NULL) != 0) {
        perror("Error joining a producer thread. \n");
        exit(1);
      }
    }

    // Wait for the consumers' threads to exit.
    if (i < *n_consumers) {

      // Raise an error if the thread could not be joined successfully.
      if (pthread_join(consumers[i], NULL) != 0) {
        perror("Error joining a consumer thread. \n");
        exit(1);
      }
    }
  }

  // Free previously allocated space.
  free(account_balance);
  free(max_accounts);
  free(num_lines);

  // Destroy the previously created queue.
  queue_destroy(my_queue);
  return 0;
}

// Define ATM function (Producer).
void *ATM(void *arg) {

  // Thread id of this thread.
  int thread_num = *((int *)arg);

  // Read operations from list_client_ops.
  while (1) {
    struct element *elem = malloc(sizeof(struct element));

    // Lock the mutex to enter the critical section safely.
    pthread_mutex_lock(&atm_lock);

    // Check if it is this thread's turn to put into queue.
    if (client_numop % (*n_producers) != (thread_num)) {

      // Check that there are still operations to be done.
      if (client_numop >= *num_lines) {

        // Release mutex.
        pthread_mutex_unlock(&atm_lock);
        break;
      }

      // Wait until it is this thread's turn to put into queue.
      pthread_cond_wait(&atm_cond, &atm_lock);
    }

    // Exit the loop if there are no more commands.
    if (client_numop >= *num_lines) {

      // Release mutex.
      pthread_mutex_unlock(&atm_lock);
      break;
    }

    // Get the specified operation.
    elem->operation = list_client_ops[client_numop][0];
    int i = 0;

    // Go through all the operators.
    while (1) {

      // Raise an error if the number of operators is incorrect.
      if (i > 3) {
        perror("Wrong number of operators. \n");
        exit(1);
      }

      // Exit the loop if there are no more operands.
      if (list_client_ops[client_numop][i + 1][0] == '\0') {
        break;
      }

      // Get the specified parameters.
      elem->amounts[i] = atoi(list_client_ops[client_numop][i + 1]);
      i++;
    }

    //  Add operations to the circular queue.
    queue_put(my_queue, elem);

    // Increment the number of performed ATM operations.
    client_numop++;

    // Signal all threads that were waiting.
    pthread_cond_broadcast(&atm_cond);

    // Release the mutex lock.
    pthread_mutex_unlock(&atm_lock);

    // Free previously allocated space.
    free(elem);
  }

  // Terminate the calling thread.
  pthread_exit(0);
}

// Define worker function (Consumer).
void *worker(void *arg) {

  int thread_num = *((int *)arg);

  // Read operations from the input file.
  while (1) {

    // Lock the mutex to enter the critical section safely.
    pthread_mutex_lock(&worker_lock);

    if (bank_numop % (*n_consumers) != (thread_num)) {

      // Check that there are still operations to be done.
      if (bank_numop >= *num_lines) {

        // Release mutex.
        pthread_mutex_unlock(&worker_lock);
        break;
      }
      
      pthread_cond_wait(&worker_cond, &worker_lock);
    }

    // Exit the loop if there are no more commands.
    if (bank_numop >= *num_lines) {

      // Release mutex.
      pthread_mutex_unlock(&atm_lock);
      break;
    }

    // Extract operation from the circular queue.
    struct element *elem = queue_get(my_queue);

    // Execute operation on the corresponding account.
    perform_operation(elem);

    // Increment the number of performed workers operations.
    bank_numop++;

    // Signal all threads that were waiting.
    pthread_cond_broadcast(&worker_cond);

    // Release the mutex lock.
    pthread_mutex_unlock(&worker_lock);
  }

  // Terminate the calling thread.
  pthread_exit(0);
}

// Extracted function used for reading the data from a file and save it into the
// 3D global array 'list_client_ops'.
int read_data(int fd) {

  // Declare and initialize the used variables.
  char buf[1024];
  int i = 0, j = 0, k = 0;

  // Read from fd into buf until getting to a newline or the end of buf.
  while (read(fd, &buf[i], 1) == 1 && buf[i] != '\n' && i < sizeof(buf) - 1) {
    i++;
  }

  // Get the number of operations.
  buf[i] = '\0';
  num_lines = malloc(sizeof(int));
  *num_lines = atoi(buf);

  // Reset the variable.
  i = 0;

  // Save the data into list_client_ops.
  while (read(fd, &list_client_ops[i][j][k], 1) > 0) {

    // Raise an error if the maximum number of operations is exceeded.
    if (i == 200) {
      perror("Number of operations exceeds 200. \n");
      exit(1);
    }

    // If the current character is a newline.
    if (list_client_ops[i][j][k] == '\n') {
      list_client_ops[i][j][k] = '\0';
      i++;
      j = 0;
      k = 0;

    }

    // If the current character is a blank space or a tab command.
    else if (list_client_ops[i][j][k] == ' ') {

      list_client_ops[i][j][k] = '\0';
      j++;
      k = 0;

    }

    else {
      k++;
    }
  }

  // Raise an error if the number of operations does not match correctly.
  if (i != *num_lines) {
    perror("Nº operations doesn't match. \n");
    exit(1);
  }

  return 0;
}

// Extracted function used for the operations (CREATE, DEPOSIT, WITHDRAW,
// BALANCE, TRANSFER).
int perform_operation(struct element *elem) {

  // Get the specified account number.
  int account_number = elem->amounts[0];

  // Raise an error if the account number is incorrect.
  if (account_number < 0 || account_number > *max_accounts) {
    perror("Invalid account Nº: max. accounts must be big enough. \n");
    exit(1);
  }

  // Get the specified operation.
  char *operation = elem->operation;

  // Divide the functionality according to the operation type.
  // Create a new account.
  if (strcmp(operation, "CREATE") == 0) {

    // Raise an error if the account already exists.
    if (account_balance[account_number] != -1) {
      handle_operation_error(1);
    }

    // Set the account balance to 0.
    account_balance[account_number] = 0;

    // Print the operation output.
    printf("%d CREATE %d BALANCE=0 TOTAL=%d\n", bank_numop + 1, account_number,
           global_balance);
  }

  // Deposit money into an account.
  else if (strcmp(operation, "DEPOSIT") == 0) {

    // If the account does not exist, the operation ends.
    if (account_balance[account_number] == -1) {
      handle_operation_error(0);
    }

    // Get the specified amount of the operation.
    int amount = elem->amounts[1];

    // Add the specified amount to the balance of the account.
    account_balance[account_number] += amount;

    // Add the specified amount to the balance of the bank.
    global_balance += amount;

    // Print the operation output.
    printf("%d DEPOSIT %d %d BALANCE=%d TOTAL=%d\n", bank_numop + 1,
           account_number, amount, account_balance[account_number],
           global_balance);
  }

  // Withdraw money from an account.
  else if (strcmp(operation, "WITHDRAW") == 0) {

    // If the account does not exist, the operation ends.
    if (account_balance[account_number] == -1) {
      handle_operation_error(0);
    }

    // Get the specified amount of the operation.
    int amount = elem->amounts[1];

    // Subtract the specified amount from the balance of the account.
    account_balance[account_number] -= amount;

    // Subtract the specified amount from the balance of the bank.
    global_balance -= amount;

    // Print the operation output.
    printf("%d WITHDRAW %d %d BALANCE=%d TOTAL=%d\n", bank_numop + 1,
           account_number, amount, account_balance[account_number],
           global_balance);
  }

  // Check the balance of an account.
  else if (strcmp(operation, "BALANCE") == 0) {

    // If the account does not exist, the operation ends.
    if (account_balance[account_number] == -1) {
      handle_operation_error(0);
    }

    // Get the specified amount of the operation.
    int amount = elem->amounts[1];

    // Get the balance of the specified account.
    int balance = account_balance[account_number];

    // Print the operation output.
    printf("%d BALANCE %d BALANCE=%d TOTAL=%d\n", bank_numop + 1,
           account_number, account_balance[account_number], global_balance);

  }

  // Transfer money from one account to another account.
  else if (strcmp(operation, "TRANSFER") == 0) {

    // If the first account does not exist, the operation ends.
    if (account_balance[account_number] == -1) {
      handle_operation_error(0);
    }

    // Get the second specified account number.
    int account_number_2 = elem->amounts[1];

    // Get the specified amount of the operation.
    int amount = elem->amounts[2];

    // If the second account does not exist, the operation ends.
    if (account_balance[account_number_2] == -1) {
      handle_operation_error(0);
    }

    // Subtract the specified amount from the first account.
    account_balance[account_number] -= amount;

    // Add the specified amount to the balance of the second account.
    account_balance[account_number_2] += amount;

    // Print the operation output.
    printf("%d TRANSFER %d %d %d BALANCE=%d TOTAL=%d\n", bank_numop + 1,
           account_number, account_number_2, amount,
           account_balance[account_number_2], global_balance);
  }

  // Raise an error if the operation is incorrect.
  else {
    perror("Invalid operation. \n");
    exit(1);
  }

  return 0;
}

// Extracted function used for printing a error message.
void handle_operation_error(int exists) {

  // If the account does not exist.
  if (exists == 0) {
    perror("The account doesn't exist. \n");
    exit(1);
  }

  // If the account already exists.
  else if (exists == 1) {
    perror("The account is already created. \n");
    exit(1);
  }
}
