#include <pthread.h>
#ifndef HEADER_FILE
#define HEADER_FILE

struct element {
  // Define the struct yourself
  char *operation;
  int amounts[4];
};

// Define a queue structure with variables, a mutex and condition variables.
typedef struct queue {
  // Define the struct yourself
  struct element *buffer;
  int head;
  int tail;
  int count;
  int size;
  pthread_mutex_t lock;
  pthread_cond_t not_empty;
  pthread_cond_t not_full;
} queue;

// Initialize the queue with the specified size.
queue *queue_init(int size);

// Declaration of the function queue_destroy, used to destroy a queue.
int queue_destroy(queue *q);

// Declaration of the function queue_put, used to enqueue an element in the
// queue.
int queue_put(queue *q, struct element *elem);

// Declaration of the function queue_get, used to dequeue an element from the
// queue.
struct element *queue_get(queue *q);

// Declaration of the function queue_empty, used to check if the queue is empty.
int queue_empty(queue *q);

// Declaration of the function queue_full, used to check if the queue is full.
int queue_full(queue *q);

#endif
