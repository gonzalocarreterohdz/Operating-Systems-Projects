// OS-P3 2022-2023

#include "queue.h"
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Create a queue.
queue *queue_init(int size) {
  if (size <= 0) {
    perror("Size of the queue has to be positive");
    exit(1);
  }
  queue *q = (queue *)malloc(sizeof(queue));
  q->buffer = (struct element *)malloc(sizeof(struct element) * size);
  q->head = 0;
  q->tail = 0;
  q->count = 0;
  q->size = size;
  pthread_mutex_init(&q->lock, NULL);
  pthread_cond_init(&q->not_empty, NULL);
  pthread_cond_init(&q->not_full, NULL);
  return q;
}

// Enqueue an element.
int queue_put(queue *q, struct element *x) {
  pthread_mutex_lock(&q->lock);
  while (queue_full(q)) {
    pthread_cond_wait(&q->not_full, &q->lock);
  }
  q->buffer[q->tail] = *x;
  q->tail = (q->tail + 1) % q->size;
  q->count++;
  pthread_cond_signal(&q->not_empty);
  pthread_mutex_unlock(&q->lock);
  return 0;
}

// Dequeue an element.
struct element *queue_get(queue *q) {
  pthread_mutex_lock(&q->lock);
  while (queue_empty(q)) {
    pthread_cond_wait(&q->not_empty, &q->lock);
  }
  struct element *element = &q->buffer[q->head];
  q->head = (q->head + 1) % q->size;
  q->count--;
  pthread_cond_signal(&q->not_full);
  pthread_mutex_unlock(&q->lock);
  return element;
}

// Check the state of the queue (empty): return 1 if it is empty and 0
// otherwise.
int queue_empty(queue *q) { return q->count == 0; }

// Check the state of the queue (full): return 1 if it is full and 0 otherwise.
int queue_full(queue *q) { return q->count == q->size - 1; }

// Destroy the queue and free the resources.
int queue_destroy(queue *q) {
  pthread_mutex_destroy(&q->lock);
  pthread_cond_destroy(&q->not_empty);
  pthread_cond_destroy(&q->not_full);
  free(q->buffer);
  free(q);
  return 0;
}
