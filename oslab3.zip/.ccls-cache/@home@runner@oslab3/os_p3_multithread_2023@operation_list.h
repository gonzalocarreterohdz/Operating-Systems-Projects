#ifndef HEADER_FILE
#define HEADER_FILE

struct element {
  // Define the struct yourself
  char *operation;
  int *amounts[];
};

typedef struct queue {
struct element *buffer;