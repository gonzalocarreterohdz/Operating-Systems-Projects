//P1-SSOO-22/23

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>    //Can be used, confirmed by the teacher
#include <unistd.h>

//The constant BUFFSIZE is defined with value 1.
#define BUFFSIZE 1

int main(int argc, char *argv[])
{
	//If less than two arguments (argv[0] -> program, argv[1] -> file to process) print an error and return -1
	if(argc < 2)
	{
		printf("Too few arguments\n");
		return -1; //or exit(1)?
	}
  int lines = 0, words = 0, bytes = 0;
  
  int fd, n;
  char buf[BUFFSIZE];
  char *filename = argv[1]; // use the filename from the command line argument

  if ((fd=open(filename,O_RDONLY,0666))<0) {
  	perror("Error opening the file\n");
    return -1;
    }
  
  //this loop read byte by byte the file opened
  
  while ((n=read(fd,buf,BUFFSIZE))>0){
    
    if(buf[0] == '\n') { //buf[0] is the actual char read
      lines++; // Increment line count for each newline character
              }
    else if (buf[0] == ' '){
      words++;
    }  
    bytes+=1;  //n is the number of bytes read
  
    if (n<0) {
       perror("Read error occured");
       return -1;
    }
    else {
       close(fd); // I think we need to check this operation is done correctly
       return 0; // Why this, if program should keep running
    }

  }

  printf("%d %d %d %s\n", lines, words, bytes, filename);

  close(fd); // I think we need to check this operation is done correctly, just like with open

	return 0; //if everything works, return 0
}