// P1-SSOO-22/23

#include <stdio.h> // Header file for system call printf

/*
For read() and close(), to read from and close
the file descriptor.
*/
#include <unistd.h> // Header file for system call gtcwd

/*
For opendir(), readdir(), closedir(). Directory-related
functions.
*/
#include <dirent.h>

/*
For string manipulation functions such as strerror,
strlen, strcpy, and strcat.
*/
#include <string.h>

/*
stdlib.h is used for the exit() function, which terminates the
program with an exit status. exit(1) could be used to indicate a failure.
*/
#include <stdlib.h>

// Define the constant macro PATH_MAX to 4096.
#define PATH_MAX 4096

int main(int argc, char *argv[]) {

  // The declared pointer is used to store the path of the directory to list.
  char *dir_path = NULL;

  // The declared pointer is used to open the directory descriptor.
  DIR *dir;

  // The declared pointer is used to point to the current directory entry that
  // is being processed in the loop that lists the contents of the directory.
  struct dirent *input;

  // If, at least, two arguments are passed, the second is used as the target
  // directory.
  if (argc > 1) {
    dir_path = argv[1];
  }

  // If no second argument is provided, it uses the current directory.
  else {
    dir_path = getcwd(NULL, 0);
  }

  // Open the directory
  dir = opendir(dir_path);

  // Handle the errors: returns -1 if no directory is found
  if (dir == NULL) {
    perror("opendir");
    return -1;
  }

  // Loop through all directory entries, read and print each one.
  while ((input = readdir(dir)) != NULL) {
    printf("%s\n", input->d_name);
  }

  // Close the directory descriptor.
  closedir(dir);

  // As the program will end successfully, it returns 0.
  return 0;
}
