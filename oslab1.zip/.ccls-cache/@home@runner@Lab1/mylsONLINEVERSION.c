#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<dirent.h>
int main(int argc,char **argv) {
  struct dirent **namelist;
  int n;

  if(argc < 1) {
    exit(EXIT_FAILURE);
  }

  else if (argc == 1) {
    n=scandir(".",&namelist,NULL,alphasort);
  }

  else {
    n = scandir(argv[1], &namelist, NULL, alphasort);
  }

  if(n < 0) {
    perror("scandir");
    exit(EXIT_FAILURE);
  }

  else {
    while (n--) {
      printf("%s\n",namelist[n]->d_name);
      //THIS LINE MUST BE printf(“ %s\n”, input->d_name); AS TOLD IN THE STATEMENT.
      //THIS LINE MUST BE printf(“ %s\n”, input->d_name); AS TOLD IN THE STATEMENT.
      //THIS LINE MUST BE printf(“ %s\n”, input->d_name); AS TOLD IN THE STATEMENT.
      free(namelist[n]);
    }

  free(namelist);
  }

exit(EXIT_SUCCESS);
}