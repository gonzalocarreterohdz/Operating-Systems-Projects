// P1-SSOO-22/23

/*
stdio.h provides input and output functionality, enabling the use of functions
like printf().
*/
#include <stdio.h> // Header file for system call printf

#include <sys/types.h> // Header file for system calls opendir, readdir and closedir

/*
unistd.h provides access to the POSIX operating system API and is used in the
code for various system calls such as read() and close() to read from and close
the file descriptor.
*/
#include <unistd.h> // Header file for system call gtcwd

/*
dirent.h is used for the opendir(), readdir(), closedir() directory-related
functions.
*/
#include <dirent.h>

/*
string.h provides various string manipulation functions such as strerror,
strlen, strcpy, and strcat.
*/
#include <string.h>

/*
errno.h provides a way to report, diagnose and handle errors that occur during
program execution.
*/
#include <errno.h>

/*
stdlib.h is used for the exit() function, which terminates the
program with an exit status. exit(1) could be used to indicate a failure.
*/
#include <stdlib.h>

int main(int argc, char **argv) {

  // The declared pointer is used to store the path of the directory to list.
  char *dir_path;

  // If no arguments are provided, it uses the current directory.
  if (argc == 1) {
    dir_path = getcwd(NULL, 0);
  }

  // If, at least, one argument is passed, it is used as the target directory.
  else {
    dir_path = argv[1];
  }

  // Open the directory.
  DIR *dir = opendir(dir_path);

  // Handle the errors: returns -1 if no directory is found
  if (dir == NULL) {
    printf("Cannot open directory '%s': %s\n", dir_path, strerror(errno));
    return -1;
  }

  // The declared pointer is used to point to the current directory entry that
  // is being processed in the loop that lists the contents of the directory.
  struct dirent *input;

  // Loop through all directory entries and print their names.
  while ((input = readdir(dir)) != NULL) {
    printf("%s\n", input->d_name);
    // THIS LINE MUST BE printf(“ %s\n”, input->d_name); AS TOLD IN THE
    // STATEMENT. THIS LINE MUST BE printf(“ %s\n”, input->d_name); AS TOLD IN
    // THE STATEMENT. THIS LINE MUST BE printf(“ %s\n”, input->d_name); AS TOLD
    // IN THE STATEMENT.
  }

  // Close the directory descriptor.
  closedir(dir);

  // Free memory.
  free(dir_path);

  // As the program will end successfully, it returns 0.
  return 0;
}
