// P1-SSOO-22/23


#include <stdio.h>

/*
For read() and close(), to read from and close
the file descriptor.
*/
#include <unistd.h>

/*
stdlib.h is used for the exit() function, which terminates the
program with an exit status. exit(1) could be used to indicate a failure.
*/
#include <stdlib.h>

/*
For string manipulation functions such as strerror,
strlen, strcpy, and strcat.
*/
#include <string.h>

/*
For open() syscall.
*/
#include <fcntl.h>

/*
errno.h provides a way to report, diagnose and handle errors that occur during
program execution. Allows the code to use perror function to print a message
when it encounters an error, indicating what went wrong.
*/
#include <errno.h>

// Define the constant macro MAXLINE to 100000.
#define MAXLINE 100000

int main(int argc, char *argv[]) {

  // If less than two arguments are passed (argv[0] -> program, argv[1] -> file
  // to save environment) print an error and return -1.
  if (argc < 3) {
    printf("Too few arguments\n");
    return -1;
  }

  // Environment variable to search.
  char *var = argv[1];

  // Output file name
  char *outfile = argv[2];

  // Declare the buffer variable.
  char buffer;

  // Buffer to store the line.
  char line[MAXLINE];

  // Position in the line buffer.
  int line_pos = 0;

  // Length of the environment variable to search.
  int var_len = strlen(var);

  // Open the input file for reading.
  int infile_fd = open("env.txt", O_RDONLY);

  // If the input file has not been opened correctly it raises an error.
  if (infile_fd == -1) {
    perror("Error opening the input file\n");
    return -1;
  }

  // The output file is opened for writing
  // O_WRONLY can be used to open the file with write-only access permissions.
  // O_CREAT can be used to create the file if it does not exist.
  // O_TRUNC can be used to truncate the file if it is a regular file that
  // already exists and is a regular file. zero bytes.
  int outfile_fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);

  // If the output file for writing has not been indicationopened correctly it
  // raises an error.
  if (outfile_fd == -1) {
    perror("Error opening the output file\n");
    close(infile_fd);
    return -1;
  }

  // The input file is read character by character.
  while ((read(infile_fd, &buffer, 1)) > 0) {

    // If the end of a line is reached, check if it contains the variable.
    if (buffer == '\n') {
      if (line_pos > var_len && strncmp(line, var, var_len) == 0 &&
          line[var_len] == '=') {

        // If the variable is found in the line, write the line to the output
        // file.
        ssize_t bytes_written = write(outfile_fd, line, line_pos);
        //print in the screen
        printf("%s\n", line);
        // If the bytes_written value is -1 it raises an error.
        if (bytes_written == -1) {
          perror("write");
          return -1;
        }

        bytes_written = write(outfile_fd, "\n", 1);

        // If the bytes_written value is -1, it raises an error.
        if (bytes_written == -1) {
          perror("write");
          return -1;
        }
      }

      // Reset the line buffer and position
      for (int i = 0; i < MAXLINE; i++) {
        line[i] = 0;
      }
      line_pos = 0;
    }

    // Otherwise, it appends the character to the line buffer.
    else {
      line[line_pos++] = buffer;
    }
  }

  // Close the input file.
  close(infile_fd);

  // Close the output file.
  close(outfile_fd);

  // As the program will end successfully, it returns 0.
  return 0;
}
