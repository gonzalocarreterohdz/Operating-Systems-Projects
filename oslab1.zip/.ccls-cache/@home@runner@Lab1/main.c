//P1-SSOO-22/23

#include <stdio.h>
#define BUFFSIZE 1

int main(int argc, char *argv[])
{
	//If less than two arguments (argv[0] -> program, argv[1] -> file to process) print an error y return -1
	if(argc < 2)
	{
		printf("Too few arguments\n");
		return -1;
	}

  int lines = 0; words = 0; 

	return 0;
}


/*
int open(const char * path, int flag)
*/
