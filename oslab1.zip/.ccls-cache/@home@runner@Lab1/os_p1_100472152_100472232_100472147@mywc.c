// P1-SSOO-22/23

#include <stdio.h>

/*
For open() syscall.
*/
#include <fcntl.h>

/*
stdlib.h is used for the exit() function, which terminates the
program with an exit status. exit(1) could be used to indicate a failure.
*/
#include <stdlib.h>

/*
For read() and close(), to read from and close
the file descriptor.
*/
#include <unistd.h>

int main(int argc, char *argv[]) {

  // If less than two arguments (argv[0] -> program, argv[1] -> file to process)
  // print an error and return -1.
  if (argc < 2) {
    printf("Too few arguments\n");
    return -1;
  }

  // The variables used as counters for lines, words and bytes, respectively,
  // are declared.
  int lines = 0, words = 0, bytes = 0;

  // The number of bytes (n) is declared.
  int n;

  // The buffer to read from the argument (file) is declared.
  char buf;

  // The filename is passed as a command-line argument.
  char *file = argv[1];

  // The flag variable is used to know if we are currently checking and counting
  // inside of a word.
  int in_word = 0;

  // If the file descriptor is smaller than 0 (negative), an error raises and it
  // returns -1. This file descriptor is the returned result of the function
  // open(), which takes three arguments: the name of the file (passed as a
  // command-line argument before), a flag (O_RDONLY, indicating read-only
  // access), and a file permission value (0444: read permissions for user,
  // group and others).
  int fd = open(file, O_RDONLY);
  
  if (fd == -1) {
    perror("Error opening the file\n");
    return -1;
  }

  // If there is no character written in the file, it prints 0 0 0.
  if ((n = read(fd, &buf, 1)) == 0) {
    // The number of lines, words, bytes and the name of the file are all
    // printed.
    printf("%d %d %d %s\n", lines, words, bytes, file);

    // The file descriptor is closed.
    close(fd);

    // As the program will end successfully, it returns 0.
    return 0;
  }

  // If there is at least a character writter in the file, it starts counting.
  // This loop reads byte by byte the opened file (passed as an argument).
  while ((n = read(fd, &buf, 1)) > 0) {
  
    // n is the number of bytes read by the function read(). Since BUFFSIZE is
    // 1, n will always be 1 (as long as the file has not been read
    // completely, then it is 0).
    bytes += n;

    // buf is the current character being read. If the current character is a
    // new line, we increment the line count.
    if (buf == '\n') {
      lines++;
      // If we are currently in a word, increment the word counter (and turn
      // off the flag).
      if (in_word) {
        words++;
        in_word = 0;
      }
    }

    // If the current character is a blank space or a tab command.
    else if ((buf == ' ') || (buf == '\t')) {

      // If we are currently in a word, increment the word counter (and turn
      // off the flag).
      if (in_word) {
        words++;
        in_word = 0;
      }
    }

    // If the current character is not a new line nor a blank space, the flag
    // is turned on.
    else {
      in_word = 1;
    }
  }

  // If n (number of bytes != counter of bytes) is smaller than zero, an error
  // raises and returns -1.
  if (n < 0) {
    perror("Read error occurred");
    return -1;
  }

  // If the file has already been checked completely and the in_word flag is
  // still one (currently in a word), the word counter is incremented. counter
  if (in_word) {
    words++;
  }

  //lines++;
  // Increment byte count one last time (value adjusted to make it correct)
  bytes++;

  // The number of lines, words, bytes and the name of the file are all printed.
  printf(" %d %d %d %s\n", lines, words, bytes, file);

  // The file descriptor is closed.
  close(fd);

  // As the program will end successfully, it returns 0.
  return 0;
}
