//P1-SSOO-22/23

#include <stdio.h>
#include <unistd.h>



int main(int argc, char *argv[])
{

    /* If less than two arguments (argv[0] -> program, argv[1] -> file to save environment) print an error y return -1 */
    if(argc < 3)
    {
    	printf("Too few arguments\n");
    	return -1;
    }

    return 0;
}

/*EMAIL FROM THE TEACHER:
	
Good afternoon,

In Lab1 for the command "myenv" you have got a file as input. The task to do in myenv is simple: look for the definition of the variable requested in the command and write the output to the file specified. 

You do not have to look for all ocurrences of the name of the variable, only the exact matching one. 

For example, with a file including the following lines:

TERM=xterm-256color

TERM_PROGRAM=Apple_Terminal 

TERM_PROGRAM_VERSION=443

TERM_SESSION_ID=E4D05CC8-6B2D-4A71-87D5-5026C5123D83

WINDOW=$TERM

The command:
$ myenv TERM > fich-salida

Should write in the output file only the next line:

TERM=xterm-256color

Best regards,
Jesús. Carretero
OS coordinator
*/