//P1-SSOO-22/23

/*
stdio.h provides input and output functionality, enabling the use of functions
like printf().
*/
#include <stdio.h>

/*
unistd.h provides access to the POSIX operating system API and is used in the
code for various system calls such as read() and close() to read from and close
the file descriptor.
*/
#include <unistd.h>

/*
stdlib.h is used for the exit() function, which terminates the
program with an exit status. exit(1) could be used to indicate a failure.
*/
#include <stdlib.h>

/*
string.h provides various string manipulation functions such as strerror,
strlen, strcpy, and strcat.
*/
#include <string.h>

/*
fcntl.h provides file control options and is used in the code to set the file
mode when opening the file with open() function.
*/
#include <fcntl.h>

/*
errno.h provides a way to report, diagnose and handle errors that occur during program execution.
*/
#include <errno.h>

#define MAXLINE 1000000

int main(int argc, char *argv[])
{

  /* If less than two arguments (argv[0] -> program, argv[1] -> file to save environment) print an error y return -1 */
  if(argc < 3)
  {
    printf("Too few arguments\n");
    return -1;
  }

  char *var = argv[1];    // variable to search for
  char *outfile = argv[2];    // output file name

  char buffer;
  char line[MAXLINE];//buffer to store the line
  int line_pos = 0;// position in the line buffer
  
  int var_len = strlen(var);    // length of the variable to search for
  int found = 0;    // flag to indicate if the variable has been found
  int written = 0;    // flag to indicate if anything has been written to the output file
  
  // Open the input file for reading
  int infile_fd = open("env.txt", O_RDONLY);
  
  if (infile_fd == -1) {
      perror("Error opening the input file\n");
      return -1;
    }

  // Open the output file for writing 
  //O_WRONLY: Open the file for write-only access.
  //O_CREAT: If the file does not exist, create it.
  //O_TRUNC: If the file already exists and is a regular file, truncate it to zero bytes.

  int outfile_fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (outfile_fd == -1) {
      perror("Error opening the input file\n");
      close(infile_fd);
      return -1;
  }

  // Read the input file character by character
  while ((read(infile_fd, &buffer, 1)) > 0) {
    // If the end of a line is reached, check if it contains the variable
    if (buffer == '\n') {
      if (line_pos > var_len && strncmp(line, var, var_len) == 0 && line[var_len] == '=') {
        // If the variable is found in the line, write the line to the output file     
        ssize_t bytes_written = write(outfile_fd, line, line_pos);
        if (bytes_written == -1) {
            perror("write");
            return -1;
        }

        bytes_written = write(outfile_fd, "\n", 1);
        if (bytes_written == -1) {
          perror("write");
          return -1;
        }

        written = 1;
        found = 1;
      }
      // Reset the line buffer and position
      for (int i = 0; i < MAXLINE; i++) {
        line[i] = 0;
      }
      line_pos = 0;
    } else {
      // Append the character to the line buffer
      line[line_pos++] = buffer;
    }
  }
  
  // Check if the variable was not found
  /*if (!found) {
      // If nothing was written to the output file, create an empty file
      if (!written) {
          write(outfile_fd, "", 0);
      }
      close(infile_fd);
      close(outfile_fd);
      return -1;
  }*/

  // Close the input and output files
  close(infile_fd);
  close(outfile_fd);

  return 0;
}