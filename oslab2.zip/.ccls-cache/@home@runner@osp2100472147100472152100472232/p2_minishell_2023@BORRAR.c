// Declared variables used to know the index inside the loop, the status of
// child processes, communicate between processes through the pipe file
// descriptors, and check if the pid belongs to a child, respectively.