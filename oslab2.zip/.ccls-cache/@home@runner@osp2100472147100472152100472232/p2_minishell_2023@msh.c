/* P2-SSOO-22/23*/

// MSH main file
// Write your msh source code here

//#include "parser.h"
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stddef.h> /* NULL */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <wait.h>
#include <ctype.h>


#define MAX_COMMANDS 8

// files in case of redirection
char filev[3][64];

// to store the execvp second parameter
char *argv_execvp[8];

int redirect(int file_desc, char* file_name, int mode); 
void execute_command(char*** command_sequence, int num_commands, int in_background);
void mycalc(char** argvv);

void siginthandler(int param) {
  printf("****  Exiting MSH **** \n");
  // signal(SIGINT, siginthandler);
  exit(0);
}

/* Timer */
pthread_t timer_thread;
unsigned long mytime = 0;

// Infinite loop that adds 1 to mytime after 1000 microsec. (1 millisec.) suspension passes.
void *timer_run() {
  while (1) {
    usleep(1000);  
    mytime++;
  }
}

// Added function used to print mytime with the correct format (HH:MM:SS).
void mytime_command(char** argvv) {

  // Message shown when syntax of my_time is not correct.
  char error_mytime[] = "[ERROR] The structure of the command is mytime\n";

  // If more words after mytime, prints the above message.
  if (argvv[1] != NULL) {
    if (write(STDOUT_FILENO, error_mytime, strlen(error_mytime)) == -1){
          perror("Write Error");
          exit(-1);
        };
    return;
  }

  // Declare the variables used to print mytime with the correct format.
  int hours, minutes, seconds;
  seconds = mytime / 1000;
  minutes = seconds / 60;
  hours = minutes / 60;

  // Bound appropriately the variables with the modulo operator.
  seconds %= 60;
  minutes %= 60;
  hours %= 24;

  // Print the ellapsed time with the correct format.
  char t[100];
  sprintf(t, "%02d:%02d:%02d\n", hours, minutes, seconds);

  // Error while writing to STDERR_FILENO.
  if (write(STDERR_FILENO, t, strlen(t)) == -1){
    perror("Write Error");
  }
}

/**
 * Get the command with its parameters for execvp
 * Execute this instruction before run an execvp to obtain the complete command
 * @param argvv
 * @param num_command
 * @return
 */
void getCompleteCommand(char ***argvv, int num_command) {
  // reset first
  for (int j = 0; j < 8; j++)
    argv_execvp[j] = NULL;

  int i = 0;
  for (i = 0; argvv[num_command][i] != NULL; i++)
    argv_execvp[i] = argvv[num_command][i];
}

/**
 * Main sheell  Loop
 */
int main(int argc, char *argv[]) {
  /**** Do not delete this code.****/  
  int end = 0;
  int executed_cmd_lines = -1;
  char *cmd_line = NULL;
  char *cmd_lines[10];
  setenv("Acc", "0", 1);

  if (!isatty(STDIN_FILENO)) {
    cmd_line = (char *)malloc(100);
    while (scanf(" %[^\n]", cmd_line) != EOF) {
      if (strlen(cmd_line) <= 0)
        return 0;
      cmd_lines[end] = (char *)malloc(strlen(cmd_line) + 1);
      strcpy(cmd_lines[end], cmd_line);
      end++;
      fflush(stdin);
      fflush(stdout);
    }
  }

  pthread_create(&timer_thread, NULL, timer_run, NULL);

  /*********************************/

  char ***argvv = NULL;
  int num_commands;
  
  while (1) {
    int status = 0;
    int command_counter = 0;
    int in_background = 0;
    signal(SIGINT, siginthandler);

    // Prompt
    if (write(STDERR_FILENO, "MSH>>", strlen("MSH>>")) == -1){
      perror("Write Error");
    }

    // Get command
    //********** DO NOT MODIFY THIS PART. IT DISTINGUISH BETWEEN
    //NORMAL/CORRECTION MODE***************
    executed_cmd_lines++;
    if (end != 0 && executed_cmd_lines < end) {
      command_counter = read_command_correction(&argvv, filev, &in_background,
                                                cmd_lines[executed_cmd_lines]);
    } else if (end != 0 && executed_cmd_lines == end) {
      return 0;
    } else {
      command_counter =
          read_command(&argvv, filev, &in_background); // NORMAL MODE
    }
    // STUDENTS CODE

    if (command_counter > 0) {
      // Commands entered more than MAX_COMMANDS
      if (command_counter > MAX_COMMANDS) {
        printf("Error: Maximum number of commands is %d \n", MAX_COMMANDS);
      } else {
        // check if the command is "mytime"
        if (strcmp(argvv[0][0], "mytime") == 0) {
          mytime_command(argvv[0]);
        } 
        // check if the command is "mycalc"
        else if (strcmp(argvv[0][0], "mycalc") == 0){
          mycalc(argvv[0]);
        }
        else {
          //print_command(argvv, filev, in_background);
          // Added function to execute the commands. Defined below.
          execute_command(argvv, command_counter, in_background); 
        }
      }
    }
  }
  return 0;
}

// This function checks if there is any input, output or error redirection, and
// if it does, it will close the file descriptor, open the specified file and
// return so the command can be executed. Otherwise, it returns. It is used to
// redirect input/output (file descriptors) from/to files.
int redirect(int file_desc, char *file_name, int mode) {
  // No redirection
  if (strcmp(file_name, "0") == 0) {
    return 0;
  }
  // There is a file to redirect to/from
  close(file_desc);
  int fd = open(file_name, mode, 0666);
  if (fd == -1) {
    perror("Error opening or creating file");
    exit(-1);
  }
  return 0;
}

void execute_command(char ***command_sequence, int num_commands,
                     int in_background) {

/* Declared variables used to know the index inside the loop, the status of
 * child processes, communicate between processes through the pipe file
 * descriptors, and check if the pid belongs to a child, respectively. */
  int i, status;
  int fd[2], fd_in = 0;
  pid_t pid;

  // Start of the loop that iterates as many times as the number of used
  // commands.
  for (i = 0; i < num_commands; i++) {

    // Error while creating the pipe.
    if (pipe(fd) == -1) {
      perror("pipe");
      exit(EXIT_FAILURE);
    }

    // Fork so the current command can be executed in the child process.
    pid = fork();

    // Error while executing fork.
    if (pid == -1) {
      perror("fork");
      exit(EXIT_FAILURE);

    // Child process.
    } else if (pid == 0) {

      // Redirects to standard error output file descriptor in filev[2].
      redirect(STDERR_FILENO, filev[2], O_CREAT | O_WRONLY | O_TRUNC);

      // If it is not the first command, read from previous command's output.
      if (i != 0) {

        // Error while duplicating the input file descriptor.
        if (dup2(fd_in, STDIN_FILENO) == -1) {
          perror("dup2");
          exit(EXIT_FAILURE);
        }
        close(fd_in);
      } else {
        // First command, check for input redirection
        redirect(STDIN_FILENO, filev[0], O_RDONLY);
      }

      // If it is not the last command, redirect output to pipe.
      if (i != num_commands - 1) {

        // Error while duplicating the output file descriptor.
        if (dup2(fd[1], STDOUT_FILENO) == -1) {
          perror("dup2");
          exit(EXIT_FAILURE);
        }
        close(fd[1]);
      } else {
        // Last command, checks for output redirection
        redirect(STDOUT_FILENO, filev[1], O_CREAT | O_WRONLY | O_TRUNC);
      }

      // Execute the command.
      execvp(command_sequence[i][0], command_sequence[i]);

      // Error while executing the command.
      perror("execvp");
      exit(EXIT_FAILURE);

      // Parent process
    } else {

      // If the command is executed in the background, wait for the child
      // process.
      if (in_background == 0) {

        // Error while waiting for the child process.
        if (waitpid(pid, &status, 0) == -1) {
          perror("waitpid");
          exit(EXIT_FAILURE);
        }
      }

      // If it is not the first command, close previous command's output.
      if (i != 0) {
        close(fd_in);
      }

      // If it is not the last command, set pipe output as input for next
      // command.
      if (i != num_commands - 1) {
        fd_in = fd[0];
        close(fd[1]);
      }
    }
  }
}

// This function checks if a given string represents a valid integer, ignoring a
// possible leading minus sign and checking that all the remaining characters
// are digits.
int isNumber(char* str) {
    int i = 0;
    if (str[i] == '-') {
        // If the first character is '-', skip it
        i++;
    }
    // Check that every character is a digit
    while (str[i]) {
        // It is not a digit
        if (!isdigit(str[i]))
            return 0;
        i++;
    }
    return 1;
}

// This function acts as a calculator based in the following format: mycalc
// <operand_1> <add/mul/div> <operand_2>.
void mycalc(char** argvv) {
    int op1, op2;
    int res, remainder;

    // From char to int the value in Acc enviroment variable.
    int AccValue = atoi(getenv("Acc"));
    char error_mycalc[] = "[ERROR] The structure of the command is mycalc <operand_1> <add/mul/div> <operand_2>\n";

    // This is what we will output.
    char expression[100];

    int count = 0;

    // Counts number of passed arguments.
    while (argvv[count] != NULL) {
        count++;
    }

    // If the number of passed arguments is less than 4 (incorrect format), it
    // returns (or raise an error).
    if (count < 4){

      // Error while writing to STDOUT_FILENO.
      if (write(STDOUT_FILENO, error_mycalc, strlen(error_mycalc))== -1){
        perror("Write Error");
        exit(-1);
      }
      return;
    }

    // If both operands are valid numbers, convert both strings to integers.
    if (isNumber(argvv[1]) && isNumber(argvv[3])) {
        op1 = atoi(argvv[1]);
        op2 = atoi(argvv[3]);
    } else {

      // Error while writing to STDOUT_FILENO.
      if (write(STDOUT_FILENO, error_mycalc, strlen(error_mycalc))== -1){
        perror("Write Error");
        exit(-1);
      }
      return;
    }

    // Add operation.
    if (strcmp(argvv[2], "add") == 0) {

        // Calculate result of operation.
        res = op1 + op2;

        // Add to enviromental variable the new result.
        sprintf(expression, "%d", res + AccValue);

        // Upsate enviromental variable.
        setenv("Acc", expression, 1);

        // Expresion we will return.
        sprintf(expression, "[OK] %d + %d = %d; Acc %d\n", op1, op2, res, AccValue + res);

        // Error while writing to STDERR_FILENO.
        if (write(STDERR_FILENO, expression, strlen(expression)) == -1){
          perror("Write Error");
          exit(-1);
        }

    // Multiplication operation.
    } else if (strcmp(argvv[2], "mul") == 0) {
        // Calculate result of operation
        res = op1 * op2;

        // Expression we will return.
        sprintf(expression, "[OK] %d * %d = %d\n", op1, op2, res);

        // Error while writing to STDERR_FILENO.
        if (write(STDERR_FILENO, expression, strlen(expression)) == -1){
          perror("Write Error");
          exit(-1);
        }

    // Division operation.
    } else if (strcmp(argvv[2], "div") == 0) {

        // Trying to divide by 0
        if (op2 == 0) {

            // Error while writing to STDOUT_FILENO.
            if (write(STDOUT_FILENO, "[ERROR] Division by zero\n", 23) == -1){
              perror("Write Error");
              exit(-1);
            };
        }

        // Calculate quotient of operation.
        res = op1 / op2;

        // Calculate remainder of operation.
        remainder = op1 % op2;

        // Expression we will return.
        sprintf(expression, "[OK] %d / %d = %d; Remainder %d\n", op1, op2, res, remainder);

        // Error while writing to STDERR_FILENO.
        if (write(STDERR_FILENO, expression, strlen(expression)) == -1){
          perror("Write Error");
          exit(-1);
        }

    // Incorrect operation (not add, nor mul, nor div).
    } else {

        // Error while writing to STDOUT_FILENO.
        if (write(STDOUT_FILENO, error_mycalc, strlen(error_mycalc)) == -1){
          perror("Write Error");
          exit(-1);
        };
    }
  return;
}